"""Reproduce Game 1 analysis; all outputs are local, hypothetical experiments."""

import argparse
import json
import os
from pathlib import Path
import time

os.environ.setdefault("MPLCONFIGDIR", "/tmp/blotto-matplotlib")

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from blotto.dynamics import double_oracle, fictitious_play, pure_response_path
from blotto.game import best_response, marginals
from blotto.opponents import (
    concentrated_population,
    heuristic_population,
    independent_soldiers,
    mixture,
    round_allocation,
    uniform_allocations,
)
from blotto.robust import minimax_regret, score_allocations


def save_json(directory, name, data):
    (directory / f"{name}.json").write_text(json.dumps(data, indent=2) + "\n")


def mixed_marginals(result):
    return marginals(result["allocations"], result["weights"])


def table(headers, rows):
    lines = [
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join(["---"] * len(headers)) + " |",
    ]
    lines += ["| " + " | ".join(map(str, row)) + " |" for row in rows]
    return "\n".join(lines)


def write_summary(output, data):
    random_rows = [
        [
            r["model"],
            str(r["allocation"]),
            f'{r["score"]:.6f}',
            f'{r["all_in_score"]:.6f}',
        ]
        for r in data["random"]
    ]
    chosen = ["balanced", "concentrated_heavy", "equilibrium_heavy", "endogenous_25H"]
    score_rows = [
        [name, str(row["allocation"])] + [f'{row["scores"][s]:.6f}' for s in chosen]
        for name, row in data["candidates"].items()
    ]
    oracle_rows = [
        [
            name,
            result["iterations"],
            f'{result["population_exploitability"]:.3g}',
            f'{result["population_score"]:.6f}',
            result["converged"],
        ]
        for name, result in data["certificates"].items()
    ]
    scenario_rows = [
        [name, str(row["allocation"]), f'{row["score"]:.6f}']
        for name, row in data["scenario_optima"].items()
    ]
    cycle_rows = [
        [name, row["cycle_start"], row["cycle_length"]]
        for name, row in data["paths"].items()
    ]
    adaptation_rows = [
        [name, f'{row["frozen_best_score"]:.6f}', f'{row["adapted_best_score"]:.6f}']
        for name, row in data["adaptation_comparison"].items()
    ]
    comparison_rows = [
        [
            name,
            str(data["candidates"][name]["allocation"]),
            f'{data["candidates"][name]["original_max_regret"]:.6f}',
            f'{data["candidates"][name]["expanded_max_regret"]:.6f}',
        ]
        for name in ["teammate", "new_minimax_regret", "expanded_minimax_regret"]
    ]
    sections = []
    for language in ("English", "中文"):
        english = language == "English"
        sections.append(f"## {language}\n")
        sections.append(
            "These are synthetic population experiments, not tournament scores. Game 1 only. All allocations list the 1-, 2-, 3-, 4-, 5-point castles in order. The original pasted results could not be reproduced without their exact model and code.\n"
            if english
            else "以下是本项目自建人群的实验，并非官方成绩。只研究第一局。配兵按1、2、3、4、5分城排列。旧分析缺少完整代码和模型参数，因此这里是重新建模，不能称为复现旧数值。\n"
        )
        sections.append(
            "H denotes the heuristic population, C the concentrated population, and E the computed original-game equilibrium. Fixed scenario weights (H, C, E) are: heuristic_heavy (50%,25%,25%), balanced (25%,25%,50%), concentrated_heavy (10%,70%,20%), equilibrium_heavy (5%,15%,80%), equilibrium (0%,0%,100%). Endogenous scenarios fix 10% H, 25% H, or 25% C and let the remaining smart population jointly adapt. Model details: [opponents.md](../blotto/opponents.md). All scores are castle points, out of 15.\n"
            if english
            else "H 表示直觉型人群，C 表示集中型人群，E 表示计算得到的原博弈均衡。固定情景的 (H,C,E) 比例分别是：heuristic_heavy (50%,25%,25%)、balanced (25%,25%,50%)、concentrated_heavy (10%,70%,20%)、equilibrium_heavy (5%,15%,80%)、equilibrium (0%,0%,100%)。三个 endogenous 情景分别固定10% H、25% H、25% C，让其余聪明人群共同适应。生成细节见 [opponents.md](../blotto/opponents.md)。所有得分均为城堡分，满分15。\n"
        )
        sections.append("### Random baselines\n" if english else "### 随机基准\n")
        sections.append(
            table(
                (
                    ["Model", "Best response", "Best score", "All-in score"]
                    if english
                    else ["随机模型", "最佳回应", "最优分数", "全押第五城得分"]
                ),
                random_rows,
            )
        )
        sections.append(
            "\n### Pure-response cycles\n" if english else "\n### 纯策略反制循环\n"
        )
        sections.append(
            table(
                (
                    ["Initial strategy", "Transient length", "Cycle length"]
                    if english
                    else ["起始策略", "过渡长度", "循环长度"]
                ),
                cycle_rows,
            )
        )
        sections.append(
            "\n### Solver certificates\n" if english else "\n### 求解误差证书\n"
        )
        sections.append(
            table(
                (
                    [
                        "Population",
                        "Iterations",
                        "Deviation gain",
                        "Smart score",
                        "Converged",
                    ]
                    if english
                    else ["人群", "LP轮数", "偏离可增分", "聪明人群均分", "达到容限"]
                ),
                oracle_rows,
            )
        )
        sections.append(
            "\nDeviation gain is the best unilateral improvement against the complete modeled population. Only the equilibrium row is a minimax equilibrium of the original game.\n"
            if english
            else "\n偏离可增分是聪明子群体面对整个模型人群时，单方改用最佳回应还能提高的分数。只有 equilibrium 行求的是原博弈的 minimax 均衡；有背景人群的行求的是子群体的适应均衡。\n"
        )
        sections.append(
            "### Exact optima by scenario\n"
            if english
            else "### 各情景的精确最佳回应\n"
        )
        sections.append(
            table(
                (
                    ["Scenario", "Best response", "Score"]
                    if english
                    else ["情景", "最佳回应", "分数"]
                ),
                scenario_rows,
            )
        )
        sections.append(
            "\n### Holding the background fixed\n"
            if english
            else "\n### 保持背景人群及其比例不变\n"
        )
        sections.append(
            table(
                (
                    ["Population", "Smart players frozen at E", "Smart players adapted"]
                    if english
                    else [
                        "人群",
                        "聪明人固定使用E时的最优分数",
                        "聪明人共同适应后的最优分数",
                    ]
                ),
                adaptation_rows,
            )
        )
        sections.append(
            "\n### Fixed candidate comparison\n"
            if english
            else "\n### 固定候选方案比较\n"
        )
        sections.append(
            table(
                (
                    ["Candidate", "Allocation"]
                    + [
                        "Balanced",
                        "Concentrated-heavy",
                        "Equilibrium-heavy",
                        "25% H + adapted",
                    ]
                    if english
                    else [
                        "候选",
                        "配兵",
                        "基准",
                        "集中型较多",
                        "均衡型较多",
                        "25% H＋适应者",
                    ]
                ),
                score_rows,
            )
        )
        robust = data["robust"]
        sections.append(
            f'\nMinimax regret: **{robust["allocation"]}**; maximum regret **{robust["max_regret"]:.6f}** points; **{robust["allocations_examined"]:,}** legal allocations examined.\n'
            if english
            else f'\nMinimax regret 配兵：**{robust["allocation"]}**；最大落后 **{robust["max_regret"]:.6f}** 分；已枚举 **{robust["allocations_examined"]:,}** 个合法向量。\n'
        )
        sections.append(
            "This candidate is conditional on the eight declared scenarios. Read [the analysis](../docs/analysis.md) for reasoning and model limitations; inspect [summary.json](summary.json) for every score and sample-seed check. Solver certificates use floating-point arithmetic. The left plot clips errors below 1e-12; its horizontal axis counts updates, not runtime. The right plot varies the assumed equilibrium population share.\n"
            if english
            else "这个候选只对明确列出的八种情景成立。推导和下一步实验见[中文分析](../docs/analysis.md)；完整得分与换种子检查见 [summary.json](summary.json)。求解误差来自浮点计算。左图将低于1e-12的误差按1e-12显示，横轴是更新次数而非运行时间；右图改变假定的均衡型人群比例。\n"
        )
        sections.append(
            "### Teammate comparison and broader proportion uncertainty\n"
            if english
            else "### 队友方案与更广的人群比例范围\n"
        )
        sections.append(
            table(
                (
                    [
                        "Candidate",
                        "Allocation",
                        "Worst regret: original 8",
                        "Worst regret: expanded 10",
                    ]
                    if english
                    else ["候选", "配兵", "原8情景最大regret", "扩展10情景最大regret"]
                ),
                comparison_rows,
            )
        )
        expanded = data["broader_search"]
        sections.append(
            f'\nThe expanded search adds pure H and pure C to the original eight scenarios. It checks all {expanded["allocations_examined"]:,} legal allocations and selects {expanded["allocation"]}. This covers every fixed H/C/E proportion through the endpoint regret bound. It also retains the three previously solved adapted populations, but does not recompute S at every new background proportion. H/C generation rules and weights within each model are unchanged.\n'
            if english
            else f'\n扩展搜索在原八种情景上加入纯H、纯C，枚举全部{expanded["allocations_examined"]:,}个合法配兵，得到{expanded["allocation"]}。端点regret界覆盖H/C/E分布固定时的任意人群比例，也保留三种已有适应人群；没有为每个新背景比例重新计算S。H/C内部生成规则未改变。\n'
        )
        sections.append("![Convergence and sensitivity](diagnostics.png)\n")
    (output / "summary.md").write_text(
        "# Game 1 experiment results\n\n" + "\n".join(sections)
    )


def plot_diagnostics(output, fp, equilibrium, sweeps):
    figure, axes = plt.subplots(1, 2, figsize=(12, 4.4), constrained_layout=True)
    for result, label in [(fp, "Fictitious play"), (equilibrium, "Double oracle")]:
        history = result["history"]
        axes[0].plot(
            [h["iteration"] + 1 for h in history],
            [max(h["exploitability"], 1e-12) for h in history],
            label=label,
        )
    axes[0].set(
        xscale="log",
        yscale="log",
        xlabel="Update count + 1 (different algorithms)",
        ylabel="Full-space exploitability (castle points)",
        title="Mixed-strategy certificates",
    )
    axes[0].legend()
    for proportion in [0.0, 0.5, 1.0]:
        rows = [r for r in sweeps if r["heuristic_share_of_remainder"] == proportion]
        axes[1].plot(
            [r["equilibrium_share"] for r in rows],
            [r["best_score"] for r in rows],
            marker=".",
            label=f"Heuristic share of remainder: {proportion:.0%}",
        )
    axes[1].axhline(7.5, color="gray", linewidth=1, linestyle=":")
    axes[1].set(
        xlabel="Assumed equilibrium share of population",
        ylabel="Best response score (castle points)",
        title="Frozen population sensitivity",
    )
    axes[1].legend(fontsize=8)
    figure.savefig(output / "diagnostics.png", dpi=170)
    plt.close(figure)


def run(args):
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    started = time.perf_counter()
    results = {"config": vars(args), "random": [], "paths": {}}
    for name, population in [
        ("uniform_allocations", uniform_allocations()),
        ("independent_soldiers", independent_soldiers()),
    ]:
        allocation, score = best_response(population)
        results["random"].append(
            {
                "model": name,
                "allocation": allocation.tolist(),
                "score": score,
                "all_in_score": float(
                    score_allocations([[0, 0, 0, 0, 100]], population)[0]
                ),
            }
        )
    for name, initial in [
        ("all_in", [0, 0, 0, 0, 100]),
        ("one_step", [1, 1, 1, 1, 96]),
        ("equal", [20] * 5),
        ("previous_candidate", [1, 14, 1, 37, 47]),
    ]:
        results["paths"][name] = pure_response_path(initial)
    print("Random baselines and pure cycles complete.", flush=True)

    equilibrium = double_oracle(
        tolerance=args.tolerance, max_iterations=args.max_iterations
    )
    fp = fictitious_play([0, 0, 0, 0, 100], iterations=args.fp_iterations)
    save_json(output, "equilibrium", equilibrium)
    save_json(output, "fictitious_play", fp)
    results["certificates"] = {
        "equilibrium": {
            k: equilibrium[k]
            for k in (
                "iterations",
                "population_exploitability",
                "population_score",
                "converged",
                "worst_case_score",
            )
        }
    }
    equilibrium_marginal = mixed_marginals(equilibrium)
    heuristic = heuristic_population(args.samples, args.seed)
    concentrated = concentrated_population(args.samples, args.seed + 1)
    scenarios = {
        "heuristic_heavy": mixture(
            [heuristic, concentrated, equilibrium_marginal], [0.5, 0.25, 0.25]
        ),
        "balanced": mixture(
            [heuristic, concentrated, equilibrium_marginal], [0.25, 0.25, 0.5]
        ),
        "concentrated_heavy": mixture(
            [heuristic, concentrated, equilibrium_marginal], [0.1, 0.7, 0.2]
        ),
        "equilibrium_heavy": mixture(
            [heuristic, concentrated, equilibrium_marginal], [0.05, 0.15, 0.8]
        ),
        "equilibrium": equilibrium_marginal,
    }
    results["adaptation_comparison"] = {}
    for name, background, fraction in [
        ("endogenous_10H", heuristic, 0.1),
        ("endogenous_25H", heuristic, 0.25),
        ("endogenous_25C", concentrated, 0.25),
    ]:
        adapted = double_oracle(
            tolerance=args.tolerance,
            max_iterations=args.max_iterations,
            background=background,
            background_weight=fraction,
        )
        save_json(output, name, adapted)
        scenarios[name] = mixture(
            [background, mixed_marginals(adapted)], [fraction, 1 - fraction]
        )
        frozen_population = mixture(
            [background, equilibrium_marginal], [fraction, 1 - fraction]
        )
        frozen_response, frozen_score = best_response(frozen_population)
        results["adaptation_comparison"][name] = {
            "frozen_best_response": frozen_response.tolist(),
            "frozen_best_score": frozen_score,
            "adapted_best_score": adapted["best_response_score"],
        }
        results["certificates"][name] = {
            k: adapted[k]
            for k in (
                "iterations",
                "population_exploitability",
                "population_score",
                "converged",
                "worst_case_score",
            )
        }
        print(
            f'{name}: residual={adapted["population_exploitability"]:.3g}, converged={adapted["converged"]}',
            flush=True,
        )

    results["scenario_optima"] = {}
    for name, population in scenarios.items():
        allocation, score = best_response(population)
        results["scenario_optima"][name] = {
            "allocation": allocation.tolist(),
            "score": score,
        }
    results["robust"] = minimax_regret(scenarios)
    # Pure H and C complete the endpoints for arbitrary fixed H/C/E mixtures.
    comparison_scenarios = {
        **scenarios,
        "heuristic_only": heuristic,
        "concentrated_only": concentrated,
    }
    results["broader_search"] = minimax_regret(comparison_scenarios)
    comparison_optima = dict(
        zip(
            results["broader_search"]["scenarios"],
            results["broader_search"]["optimal_scores"],
        )
    )
    candidates = {
        "equal": [20] * 5,
        "proportional": [7, 13, 20, 27, 33],
        "previous_baseline": [1, 1, 21, 31, 46],
        "previous_concentrated": [1, 1, 1, 41, 56],
        "previous_robust": [1, 14, 1, 37, 47],
        "new_balanced_best": results["scenario_optima"]["balanced"]["allocation"],
        "new_minimax_regret": results["robust"]["allocation"],
        "teammate": [2, 16, 1, 37, 44],
        "expanded_minimax_regret": results["broader_search"]["allocation"],
        "rounded_equilibrium_mean": round_allocation(
            np.asarray(equilibrium["weights"]) @ np.asarray(equilibrium["allocations"])
        ).tolist(),
    }
    results["candidates"] = {}
    for name, allocation in candidates.items():
        _, adversary_score = best_response(marginals([allocation]))
        scores = {
            s: float(score_allocations([allocation], q)[0])
            for s, q in comparison_scenarios.items()
        }
        regrets = {s: comparison_optima[s] - scores[s] for s in comparison_scenarios}
        results["candidates"][name] = {
            "allocation": allocation,
            "worst_case_score": 15 - adversary_score,
            "scores": scores,
            "regrets": regrets,
            "original_max_regret": max(regrets[s] for s in scenarios),
            "expanded_max_regret": max(regrets.values()),
        }

    sweeps = []
    for heuristic_share in [0.0, 0.5, 1.0]:
        for equilibrium_share in np.linspace(0, 1, 21):
            q = mixture(
                [heuristic, concentrated, equilibrium_marginal],
                [
                    (1 - equilibrium_share) * heuristic_share,
                    (1 - equilibrium_share) * (1 - heuristic_share),
                    equilibrium_share,
                ],
            )
            allocation, score = best_response(q)
            sweeps.append(
                {
                    "equilibrium_share": float(equilibrium_share),
                    "heuristic_share_of_remainder": heuristic_share,
                    "best_response": allocation.tolist(),
                    "best_score": score,
                }
            )
    save_json(output, "sensitivity", sweeps)
    # Hold the selected vector fixed; only regenerate the assumed population.
    seed_checks = []
    for offset in range(1, 6):
        h = heuristic_population(args.samples, args.seed + 100 * offset)
        c = concentrated_population(args.samples, args.seed + 100 * offset + 1)
        q = mixture([h, c, equilibrium_marginal], [0.25, 0.25, 0.5])
        _, optimum = best_response(q)
        score = float(score_allocations([results["robust"]["allocation"]], q)[0])
        seed_checks.append(
            {
                "seed": args.seed + 100 * offset,
                "score": score,
                "regret": optimum - score,
            }
        )
    results["seed_checks_balanced"] = seed_checks
    results["elapsed_seconds"] = time.perf_counter() - started
    save_json(output, "summary", results)
    save_json(
        output,
        "comparison",
        {
            "original_search": results["robust"],
            "expanded_search": results["broader_search"],
            "candidates": {
                name: results["candidates"][name]
                for name in [
                    "teammate",
                    "new_minimax_regret",
                    "expanded_minimax_regret",
                ]
            },
        },
    )
    save_json(
        output,
        "scenario_marginals",
        {name: q.tolist() for name, q in scenarios.items()},
    )
    plot_diagnostics(output, fp, equilibrium, sweeps)
    write_summary(output, results)
    print(
        f'Finished in {results["elapsed_seconds"]:.1f}s: {output / "summary.md"}',
        flush=True,
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", default="results")
    parser.add_argument("--seed", type=int, default=20261103)
    parser.add_argument("--samples", type=int, default=4000)
    parser.add_argument("--tolerance", type=float, default=1e-8)
    parser.add_argument("--max-iterations", type=int, default=1500)
    parser.add_argument("--fp-iterations", type=int, default=10000)
    run(parser.parse_args())
