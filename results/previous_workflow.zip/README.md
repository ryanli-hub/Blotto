# Blotto：第一局策略实验

本项目研究 [Rules.md](Rules.md) 的 Game 1：100名士兵、五座价值1至5分的城堡，最大化平均城堡分。当前已实现最佳回应、逐层反制循环、混合均衡、共同适应的人群模型和全空间 minimax regret。

先读 [中文分析与实验结论](docs/analysis.md)，再看 [本次运行结果](results/summary.md)。关键结论是：纯策略反制必然循环；混合均衡存在，但最终提交一个固定向量时必须区分混合分布与抽出的配兵。当前八种人为情景下的 minimax regret 候选是 `(1,2,2,40,55)`，不是对真实人群的无条件推荐。

面向队友的最新英文说明见 [team_update.md](docs/team_update.md)，包含 H/C/E/S 的例子、regret 的含义，以及队友 `(2,16,1,37,44)` 的比较。扩展到任意固定 H/C/E 比例后，新候选为 `(2,2,3,39,54)`；它优化的是更广的情景范围，原八情景最优解保持不变。数值见 [comparison.json](results/comparison.json)。

## 运行

本机已有 Baruch Python 环境：

```bash
cd /Users/ryanli/Temp/Blotto
/opt/anaconda3/envs/baruch/bin/python run_experiments.py
/opt/anaconda3/envs/baruch/bin/python -m unittest discover -s tests -v
```

其他机器可用 Python 3.10 以上环境：

```bash
python -m pip install -r requirements.txt
python run_experiments.py
python -m unittest discover -s tests -v
```

默认实验会覆盖 `results/` 中的生成文件。用 `--output results_other --seed 20261203` 保存另一组实验。原始规则保持不变，程序不会提交网页表单。

## 文件与阅读顺序

| 代码 | 功能 | 英文在前、中文在后的说明 |
| --- | --- | --- |
| [blotto/game.py](blotto/game.py) | 合法配兵、计分、边际分布、DP 最佳回应 | [game.md](blotto/game.md) |
| [blotto/dynamics.py](blotto/dynamics.py) | 纯反制循环、fictitious play、double oracle、背景人群适应 | [dynamics.md](blotto/dynamics.md) |
| [blotto/opponents.py](blotto/opponents.py) | 两种随机基准、行为模型、混合人群 | [opponents.md](blotto/opponents.md) |
| [blotto/robust.py](blotto/robust.py) | 分块枚举全部配兵，最小化跨情景最大 regret | [robust.md](blotto/robust.md) |
| [run_experiments.py](run_experiments.py) | 组织实验、保存 JSON、生成表格和图 | [run_experiments.md](run_experiments.md) |
| [tests/test_game.py](tests/test_game.py) | 13项独立计分、优化与模型测试 | [test_game.md](tests/test_game.md) |

`results/equilibrium.json` 保存合法完整配兵和混合权重；`results/scenario_marginals.json` 保存本次八种情景的概率表；`results/summary.json` 保存所有候选得分和循环路径。所有人群比例是实验设置。旧分析缺少完整生成器，因此本项目是可复核的新实验，不声称复现旧数值。
