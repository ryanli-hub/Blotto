# Game 1: testing one further level of reasoning

## English

**Recommendation: keep `8 / 9 / 10 / 11 / 62`.** We found a more defensive alternative, `5 / 11 / 11 / 12 / 61`, but broader testing favored the original. A final exhaustive search that protected its existing strengths selected the original allocation again.

### 1. Reading the previous table

Our score is the average castle points won across opponents, out of 15. **Regret = the highest achievable score against that population − our score.**

The previous validation groups had maximum regrets of 1.039 for fresh samples, 1.706 for changed bidding habits, 1.466 for deeper reasoning, and 0.160 for shared recommendations. For example, the hardest changed-bidding case allowed 10.993 points; we scored 9.287, leaving 1.706 regret. Our actual scores ranged from 8.240 to 10.162 across those 34 populations.

The separate benchmark table reports **scores**:

| Opponent population | Teammate | Previous eight-scenario | Previous broader model | 8 / 9 / 10 / 11 / 62 |
|---|---:|---:|---:|---:|
| E | 7.500 | 7.500 | 7.500 | 7.500 |
| 5% H + 47.5% C + 47.5% fully adjusted S | 7.655 | 7.742 | 7.862 | 7.900 |

**E** is the original game's equilibrium distribution. The best achievable score against it is 7.5, and all four listed candidates attain that maximum.

In the second row, simple-template H and concentrated C stay fixed. S adjusts to the whole population, including other S players. Fixed H and C leave exploitable patterns, allowing the maximum to exceed 7.5. Once that population is fixed, its best achievable score is **7.900**, which our allocation attains. Its regret in that row is therefore approximately zero. Adding a new opponent type changes the population and requires a new evaluation.

### 2. What if others reach our level?

The threat is concrete. Against our allocation, **`4 / 10 / 11 / 12 / 63` wins 14:1**: it takes four soldiers from castle 1 and adds one to each remaining castle.

This shares the threshold-crossing idea with the earlier higher-small-bid test. That earlier test changed C's secondary bids to 0–4 soldiers. Here we explicitly add players who recognize our strategy pattern.

We model two groups: peers who optimize against the full earlier H/C/S population or adopt our allocation, and anticipators who respond to a population containing such peers. Their combined actual share ranges from **0% to 15%**. Direct counters to specific allocations receive a separate stress test.

### 3. What did we test?

1. **Search for a counter-adjustment.** The 74 previously observed populations generate 518 scenarios with peers and anticipators. Searching all **4,598,126** allocations selects `5 / 11 / 11 / 12 / 61`. Adding direct counters gives 666 scenarios and selects the same allocation.
2. **Check fresh populations and another reasoning step.** Two new population sets reveal a tradeoff: the alternative helps against a larger anticipating group but loses ground when that group is small or opponents adapt again.
3. **Protect the original strategy's strengths.** Allow at most **0.10 points of score loss in each of 222 now-known base populations**, then minimize maximum regret over 2,442 observed scenarios. Full search selects **`8 / 9 / 10 / 11 / 62` again**.
4. **Freeze the choice and test a third fresh set.** It contains 74 new base populations and 888 distinct scenarios after adding peers, anticipation, further responses, and direct counters. This final set remains outside strategy selection.

### 4. Final independent results

Each entry is the **largest regret** in that group. Added groups total at most 15%; smaller is better.

| Third fresh test set | Original: 8 / 9 / 10 / 11 / 62 | Alternative: 5 / 11 / 11 / 12 / 61 |
|---|---:|---:|
| Base populations | **1.804** | 2.230 |
| Peers and anticipators | 2.379 | **2.230** |
| A further response to both candidates | 2.431 | **2.388** |
| Direct counters to either candidate | **2.517** | 2.719 |
| **All final scenarios combined** | **2.517** | **2.719** |

The alternative's mechanism works: it scores **9:6 against the original**, and **6.5 against the old 14:1 counter**, compared with the original's 1 point. The cost is lower performance against ordinary populations: in one fresh base population it loses **0.498 points** relative to the original.

Across the combined final tests, limiting the added group to 5% gives maximum regrets **1.885 versus 2.292**; a 10% limit gives **2.136 versus 2.373**, again favoring the original.

### 5. Why the proportion test is reliable

For fixed base and added-type distributions, testing the 0% and 15% endpoints bounds every intermediate proportion. For example, the 5% population is two-thirds of the 0% population plus one-third of the 15% population. The score difference between any two allocations follows the same weighted average, so its worst value cannot exceed the endpoint maximum. Taking the best alternative gives the same bound for regret. The argument also covers mixtures of the fixed added types.

Fresh opponent generation and further reasoning are checked separately because they change the added types themselves. **The experiments support retaining the original as our broader defensive choice; the alternative is useful specifically against the modeled first counter-adjustment.**

---

## 中文

**建议保留 `8 / 9 / 10 / 11 / 62`。** 我们找到了更侧重防守的备选 `5 / 11 / 11 / 12 / 61`，但扩大检验范围后，原方案表现更好。最后一次保护原有优势的全量搜索，也重新选出了原方案。

### 1. 上一张表怎么读？

得分是面对各对手的平均城堡分，满分 15 分。**Regret = 面对该人群的最高可得分 − 我们的得分。**

此前四类检验的最大 regret 分别是：新样本 1.039、改变出价习惯 1.706、更深推理 1.466、共同推荐 0.160。例如，改变出价习惯组最不利的场景，最高可得 10.993 分，我们得 9.287 分，差 1.706 分。在此前 34 个人群中，我们的实际得分范围为 8.240–10.162 分。

单独基准表列的是**得分**：

| 对手人群 | 同学方案 | 原八场景方案 | 原扩展模型方案 | 8 / 9 / 10 / 11 / 62 |
|---|---:|---:|---:|---:|
| E | 7.500 | 7.500 | 7.500 | 7.500 |
| 5% H + 47.5% C + 47.5% 充分调整的 S | 7.655 | 7.742 | 7.862 | 7.900 |

**E** 是原博弈的均衡分布。面对它，最高可得分为 7.5，表中的四个候选都达到了这个上限。

第二行固定简单模板型 H 和集中型 C，让 S 针对整个人群调整，包括其他 S。固定的 H、C 仍有可利用的规律，所以最高分可以超过 7.5。随后固定这个人群，其最高可得分为 **7.900**，我们的配兵达到了它，所以在这一行的 regret 约为零。加入新的对手类型后，人群发生变化，需要重新评价。

### 2. 如果别人也想到我们这一层？

这个威胁很具体。**`4 / 10 / 11 / 12 / 63` 能以 14:1 击败当前方案**：从第一城撤四人，给其余四座城各加一人。

这与之前“小额出价更高”的检验都利用了跨越兵力门槛的思路。之前改变的是 C 在次要城投入 0–4 人的习惯；这次明确加入能够识别我们策略模式的人。

新增两类人：同层思考者针对完整的旧 H/C/S 人群优化，或采用我们的配兵；预判者再针对包含这些同层思考者的人群反制。新增群体的实际总比例为 **0%–15%**。准确针对某个具体配兵的反制，另外做压力检验。

### 3. 依次做了什么实验？

1. **寻找反制调整。** 以已经观察过的 74 个人群为基础，构造 518 个含同层思考者和预判者的场景。搜索全部 **4,598,126** 种配兵，选出 `5 / 11 / 11 / 12 / 61`。加入直接反制后共 666 个场景，仍选出同一方案。
2. **换新人群，并多推一层。** 两批新人群显示了取舍：新增群体较多时，备选方案更有利；但新增群体较少或对手再次调整时，它会失去优势。
3. **保护原方案的优势。** 要求在此时已知的 222 个基础人群中，每个人群的得分最多比原方案少 **0.10 分**，再最小化 2,442 个已观察场景中的最大 regret。全量搜索重新选出 **`8 / 9 / 10 / 11 / 62`**。
4. **固定选择，用第三批全新人群检验。** 新生成 74 个基础人群，加入同层思考、预判、进一步反制和直接针对后，共 888 个不同场景。这批数据保留作最终检验。

### 4. 最终独立检验结果

每个数字都是该组的**最大 regret**。新增群体总比例不超过 15%，数字越小越好。

| 第三批全新检验 | 原方案：8 / 9 / 10 / 11 / 62 | 备选：5 / 11 / 11 / 12 / 61 |
|---|---:|---:|
| 基础人群 | **1.804** | 2.230 |
| 同层思考者与预判者 | 2.379 | **2.230** |
| 针对两个候选再推一层 | 2.431 | **2.388** |
| 直接针对任一候选 | **2.517** | 2.719 |
| **全部最终场景合并** | **2.517** | **2.719** |

备选方案的反制机制有效：它面对原方案得 **9:6**；面对之前那个 14:1 的反制，能得 **6.5 分**，原方案只能得 1 分。代价是面对基础人群时变弱：在一个全新基础人群中，它比原方案少 **0.498 分**。

在合并后的最终检验中，若新增群体上限为 5%，两者最大 regret 分别为 **1.885、2.292**；上限为 10% 时为 **2.136、2.373**，同样支持保留原方案。

### 5. 为什么比例检验的逻辑可靠？

当基础人群和新增类型的配兵分布固定时，检验 0% 与 15% 两个端点，就能约束所有中间比例。例如，5% 的人群等于三分之二的 0% 人群，加三分之一的 15% 人群。任意两个配兵的得分差，也按同样权重平均，因此不会超过端点上的最大差距。再对所有替代配兵取最大值，就得到 regret 的端点保证。不同新增类型之间的混合也适用。

重新生成人群或增加推理层，会改变新增类型本身，因此另做独立检验。**本轮结果支持保留原方案，作为覆盖范围更广的防守选择；备选方案适合专门应对模型中的第一轮反制调整。**

---

Reproduce / 复现：`python run_anticipation.py`

[Method and parameters / 方法与参数](../run_anticipation.md) · [First-stage results / 第一阶段结果](../results/anticipation/comparison.json) · [Final results / 最终结果](../results/anticipation/refinement.json)
