# Game 1: revised experiments

## English

**Current choice: `8 / 9 / 10 / 11 / 62`.** It substantially improves robustness over our three existing candidates in the revised experiments.

### 1. Who are we playing against?

We submit 100 soldiers across castles worth 1–5 points. Our score is the average castle points won across opponents; ties split points.

- **H, simple templates:** equal spending, proportional spending, or 50/50 on the two largest castles. We test H shares of **0%, 5%, 10%, and 15%**.
- **C, considered concentration:** focus on two to four castles and usually leave **1–3 soldiers** elsewhere. We vary small bids, rounding, and willingness to compete for castle 5.
- **S, finite reasoning:** level 1 responds to an assumed H/C population; levels 2 and 3 also consider earlier levels. Players hold different beliefs and choose allocations within 0.10 points of their believed optimum. All reasoning happens before submission.
- **E, equilibrium:** a weighted lottery over legal allocations whose best counterstrategy scores 7.5. Separate benchmarks test E and a population where S fully adjusts to H, C, and other S players.

The central scenario contains **5% H, 47.5% C, and 47.5% S**.

### 2. What did we optimize?

**Regret is the best achievable score against a population minus our score.** In the central scenario, the best allocation scores 9.820 and our new allocation scores 9.554, giving regret of **9.820 − 9.554 = 0.266 points**.

We minimize the **largest regret** across selection scenarios, seeking one fixed allocation that stays close to the best choice as opponents change.

### 3. What experiments did we run?

1. **Build 40 selection scenarios:** three C profiles × four H shares × three C/S and reasoning-depth mixes, plus four shared-recommendation scenarios. S occupies 25%, 50%, or 75% of non-H players. Each C profile uses 4,000 generated allocations.
2. **Search all 4,598,126 legal allocations** for the smallest maximum regret.
3. **Freeze the winner and check 34 new scenarios:** 18 fresh samples, 12 changed bidding habits, two fourth-level reasoning cases, and two stronger shared-recommendation cases.
4. **Evaluate E and fully adjusted S separately.**

### 4. How did the candidates compare?

Allocations are ordered by castle value, from 1 to 5. Scores and regret are measured in castle points; **lower regret is better**.

| Candidate | Allocation | Central score | Largest regret: selection | Largest regret: validation |
|---|---|---:|---:|---:|
| Teammate | 2 / 16 / 1 / 37 / 44 | 6.610 | 4.963 | 4.856 |
| Previous eight-scenario choice | 1 / 2 / 2 / 40 / 55 | 7.259 | 5.384 | 5.514 |
| Previous broader-model choice | 2 / 2 / 3 / 39 / 54 | 7.376 | 5.319 | 5.525 |
| **New choice** | **8 / 9 / 10 / 11 / 62** | **9.554** | **1.133** | **1.706** |

The new allocation beats all three old candidates in all 40 selection scenarios. In validation, it beats the teammate and previous-eight choices in all 34 cases, and the broader choice in 33, trailing by 0.057 in the remaining case.

**Why the change?** In central S, roughly 66%–80% place 3–7 soldiers on each of castles 1–3. Our old 1–3 bids lose these contests. The new allocation crosses more thresholds while keeping 62 for castle 5. Against central S, it scores **10.619**, versus **5.159** for the previous broader choice. S players optimize their own population beliefs; their responses create a common pattern we can exploit.

### 5. How robust is the improvement?

The new allocation’s largest validation regret is **1.039** with fresh samples, **1.706** with changed bidding habits, **1.466** with deeper reasoning, and **0.160** with stronger shared recommendations. Its average score across opponents ranges from **8.240 to 10.162** across these 34 populations.

| Separate benchmark: average score | Teammate | Previous eight | Previous broader | New |
|---|---:|---:|---:|---:|
| E | 7.500 | 7.500 | 7.500 | 7.500 |
| 5% H + 47.5% C + 47.5% fully adjusted S | 7.655 | 7.742 | 7.862 | **7.900** |

Both equilibrium calculations passed the exact best-response check to numerical precision. The new allocation attains the best score against the fully adjusted population, with its advantage over the previous broader choice shrinking to **0.038 points**.

The next target is the high-small-bid validation scenario: we score **9.287**, versus the best response’s **10.993**, leaving the largest remaining regret of **1.706**.

---

## 中文

**当前选择：`8 / 9 / 10 / 11 / 62`。** 在新版实验中，它的稳健性明显优于三个现有候选。

### 1. 我们面对什么对手？

我们把 100 人分到价值为 1–5 分的五座城。成绩是面对各对手时的平均城堡分，并列时平分该城分数。

- **H，简单模板型：** 平均分配、按城堡价值分配，或者在最后两座城各放 50 人。测试其比例为 **0%、5%、10%、15%**。
- **C，经过考虑的集中型：** 重点争夺两到四座城，其他城通常放 **1–3 人**。我们改变小额投入、取整习惯，以及参与第五城竞争的倾向。
- **S，有限推理型：** 第一层针对自己预想的 H/C 人群；第二、三层也考虑较低层会怎么选。玩家判断不同，可以选择比自己判断下的最优分数低至多 0.10 分的配兵。推理全部发生在提交前。
- **E，均衡：** 按给定概率抽取合法配兵，针对这种抽取方式的最佳反制能拿 7.5 分。单独的基准测试包含 E，以及让 S 充分针对 H、C 和其他 S 调整的人群。

中央场景包含 **5% H、47.5% C、47.5% S**。

### 2. 我们优化什么？

**Regret 是面对某个人群时，最高可得分减去我们的得分。** 中央场景的最优配兵得 9.820，新配兵得 9.554，因此 regret 为 **9.820 − 9.554 = 0.266 分**。

我们最小化选策略场景中的**最大 regret**，寻找一个在人群变化时仍接近最好选择的固定配兵。

### 3. 依次做了哪些实验？

1. **建立 40 个选策略场景：** 三类 C × 四种 H 比例 × 三种 C/S 比例与推理深度组合，再加四个共同推荐场景。S 占非 H 玩家的 25%、50% 或 75%。每个 C 行为版本生成 4,000 个配兵。
2. **搜索全部 4,598,126 种合法配兵**，找出最大 regret 最小的方案。
3. **固定选出的配兵，检验 34 个新场景：** 18 个更换随机样本，12 个改变出价习惯，两个加入第四层推理，两个让共同推荐更加集中。
4. **单独评价 E 和充分调整的 S。**

### 4. 三个旧候选与新候选表现如何？

配兵按 1–5 分城排列。得分和 regret 的单位都是城堡分，**regret 越低越好**。

| 候选 | 配兵 | 中央场景得分 | 选策略场景最大 regret | 检验场景最大 regret |
|---|---|---:|---:|---:|
| 同学的方案 | 2 / 16 / 1 / 37 / 44 | 6.610 | 4.963 | 4.856 |
| 原八场景方案 | 1 / 2 / 2 / 40 / 55 | 7.259 | 5.384 | 5.514 |
| 原扩展模型方案 | 2 / 2 / 3 / 39 / 54 | 7.376 | 5.319 | 5.525 |
| **新方案** | **8 / 9 / 10 / 11 / 62** | **9.554** | **1.133** | **1.706** |

新方案在所有选策略场景中都超过三个旧方案。在检验组中，它在全部 34 个场景中超过同学方案和原八场景方案，在 33 个场景中超过原扩展模型方案；剩余一个场景落后 0.057 分。

**为什么会改变？** 中央场景的 S 在前三座城分别有约 66%–80% 的人投入 3–7 人，旧方案的 1–3 人会输掉这些竞争。新方案跨过更多门槛，同时保留 62 人争夺第五城。面对中央场景中的 S，新方案得 **10.619 分**，原扩展模型方案得 **5.159 分**。S 针对各自预想的人群优化，这些反制形成了我们可以利用的共同模式。

### 5. 改进有多稳健？

新方案在更换随机样本时的最大 regret 为 **1.039**，改变出价习惯时为 **1.706**，增加推理深度时为 **1.466**，共同推荐更集中时为 **0.160**。在这 34 个人群中，它面对对手的平均得分范围为 **8.240–10.162 分**。

| 单独基准：平均得分 | 同学方案 | 原八场景 | 原扩展模型 | 新方案 |
|---|---:|---:|---:|---:|
| E | 7.500 | 7.500 | 7.500 | 7.500 |
| 5% H + 47.5% C + 47.5% 充分调整的 S | 7.655 | 7.742 | 7.862 | **7.900** |

两个均衡计算都通过了精确最佳反制检验，误差在数值精度范围内。新方案面对充分调整的人群，也达到了该人群下的最优得分，对原扩展模型方案的优势缩小到 **0.038 分**。

下一步应重点处理“小额出价更高”的检验场景：我们得 **9.287 分**，最佳反制得 **10.993 分**，留下本次最大的 **1.706 分 regret**。

---

Reproduce / 复现：`python run_experiments.py`

[Experiment design / 实验设置](../run_experiments.md) · [Exact results / 完整数值](../results/revised/comparison.json)
