# Game 1: progress update for the team

This update explains our opponent models, what we are optimizing, and how three candidate allocations compare. All results below use our synthetic populations, not actual tournament submissions. The snapshot uses the default models and seed in `run_experiments.py`, checked on November 3, 2026.

We allocate 100 soldiers across castles worth 1, 2, 3, 4, and 5 points. An allocation such as `2 / 16 / 1 / 37 / 44` follows that castle order. We maximize average castle points across opponents, out of 15. A castle tie gives each player half its value. Winning more individual matchups is not the scoring objective.

## Four models of opponent behavior

H, C, E, and S describe decision rules. They are not measured categories of applicants or an intelligence ranking. Their allocation shapes can overlap: a simple heuristic can produce a concentrated allocation too.

### H: heuristic players

H represents players using recognizable rules of thumb. Examples included in the model are:

- `20 / 20 / 20 / 20 / 20`: spread soldiers equally.
- `7 / 13 / 20 / 27 / 33`: allocate roughly in proportion to castle value.
- `0 / 0 / 0 / 50 / 50`: focus equally on the two highest-value castles.

The generator chooses among six such starting allocations. Half of its 4,000 synthetic players keep their selected allocation exactly; the other half make eight small, budget-preserving soldier transfers. This keeps common-number clusters while adding variation. Once generated, H is held fixed during a population-composition experiment.

### C: concentrated players

C represents players who choose a subset of castles to contest and leave the others empty. Illustrative legal allocations are `0 / 0 / 25 / 35 / 40` and `0 / 0 / 0 / 45 / 55`.

Our generator chooses two, three, or four active castles. It favors subsets with higher total point value, then varies spending among the selected castles and rounds to exactly 100 soldiers. It generates 4,000 synthetic allocations. C is also fixed once generated; it does not continually react to the rest of the population.

The distinction from H is the generation rule. The two labels are not mutually exclusive descriptions of how an allocation looks.

### E: the original game's equilibrium distribution

E is a probability distribution over complete, legal allocations. It is not one special five-number answer, and it is not the average of those answers.

For example, two entries in our computed equilibrium are:

| Complete allocation | Probability of selecting it |
| --- | ---: |
| `0 / 4 / 38 / 17 / 41` | about 1.747% |
| `6 / 4 / 8 / 27 / 55` | about 1.375% |

The remaining probability is spread across 197 other positive-weight allocations. These two rows are examples from the full distribution; using only these two would not reproduce the equilibrium.

An E player draws one complete allocation before submitting. The entry stays fixed for all matchups. Across many independent E players, their submitted allocations follow this distribution.

Why use it? Suppose an opponent knows our entire randomization rule, including every allocation and its probability, but does not see our particular draw before choosing. Against a true equilibrium distribution, the opponent cannot earn more than 7.5 points on average. Since every matchup distributes 15 points, our average is at least 7.5. If both players use E, each averages 7.5.

This is a guarantee about expected performance before the draw. A particular allocation drawn from E can still be beaten. Averaging all the allocation vectors and submitting the resulting numbers does not inherit the guarantee.

We computed E by maintaining a manageable collection of allocations, optimizing their probabilities, and using dynamic programming to search every legal allocation for a stronger counter. If one exists, we add it and optimize again. This is Double oracle. After 300 iterations, a full-space best-response check found an advantage over 7.5 of approximately `4.6e-14`, within floating-point precision. We also ran Fictitious play, which uses historical frequencies as probabilities; its 10,000-update result still had an advantage of about 0.1422 points. These are numerical results, not a claim of an exact-arithmetic proof or equal computational cost per iteration.

E is a defensive benchmark. It need not earn as much as a targeted strategy against opponents with predictable weaknesses.

### S: players who adapt to the whole population

S represents players who try to exploit the actual modeled field, while recognizing that other adaptive players are doing the same.

For an intuitive example, if many opponents use `20 / 20 / 20 / 20 / 20`, a response such as `16 / 21 / 21 / 21 / 21` takes the four higher-value castles and scores 14 against them. But if everyone else finds the same response, further adjustment becomes worthwhile. S models that mutual adjustment rather than stopping at the first counter.

Consider a population with 25% H and 75% S. H remains fixed. We solve for an S distribution whose players cannot improve their average score by switching to another allocation against that entire population. S may use any legal allocation; it is not restricted to concentrated play.

This adapted distribution differs from E. In our model, leaving 75% of players at E makes a best response worth 8.1755 points against `25% H + 75% E`. Allowing that 75% to adapt reduces the best achievable score against the resulting field to 7.6546. Other adaptive players are also exploiting H, so the opportunity available to us shrinks.

We originally solved three such populations: `10% H + 90% S`, `25% H + 75% S`, and `25% C + 75% S`. Each has its own newly calculated S. In the H-only background cases, there is no separate fixed C subgroup. These are selected scenarios, not a complete search over all backgrounds.

## Our objective: a fixed allocation that stays close to the best

We do not know the real population proportions. Choosing a strategy that excels only under one guessed population could be fragile. Our target is a fixed allocation whose loss relative to the best choice stays small across plausible populations.

That loss is called **regret**:

\[
\text{regret}=\text{best achievable average score for that population}
-\text{our allocation's average score}.
\]

For example, against our `25% H + 25% C + 50% E` population, the best allocation scores 8.510594. Our original candidate `1 / 2 / 2 / 40 / 55` scores 8.503219. Its regret is:

\[
8.510594-8.503219=0.007375\text{ points}.
\]

The teammate's allocation scores 8.119531 against that same population, so its regret is 0.391063 points. Regret measures a missed opportunity under a specific population, not a probability of losing.

We minimize the **largest regret** across the populations being considered. This avoids assigning an unjustified probability to each whole scenario. It also accounts for differences in difficulty: scoring 7.5 against E is optimal, whereas scoring 7.5 against an easily exploited population may leave substantial points unclaimed.

The desired stability is small regret, not an almost constant raw score. No fixed allocation can have small regret against every imaginable opponent population. Indeed, each fixed allocation has a tailored opponent that holds it to at most 5 points, while a best response to that opponent can score at least 10. Our claims therefore concern a declared family of populations.

## Comparing the teammate's strategy and our candidates

We evaluated three allocations:

- **Teammate:** `2 / 16 / 1 / 37 / 44`.
- **Original candidate:** `1 / 2 / 2 / 40 / 55`.
- **New broader candidate:** `2 / 2 / 3 / 39 / 54`.

These are expected castle points against exactly the same modeled populations. The first eight rows are the original scenario set; the last two extend its proportion coverage.

| Opponent population | Teammate | Original | New broader candidate |
| --- | ---: | ---: | ---: |
| 50% H + 25% C + 25% E | 8.4934 | 9.0731 | 9.0920 |
| 25% H + 25% C + 50% E | 8.1195 | 8.5032 | 8.4972 |
| 10% H + 70% C + 20% E | 8.3375 | 8.9412 | 8.8647 |
| 5% H + 15% C + 80% E | 7.7222 | 7.8740 | 7.8604 |
| 100% E | 7.5000 | 7.5000 | 7.5000 |
| 10% H + 90% adapted S | 7.5505 | 7.5505 | 7.5505 |
| 25% H + 75% adapted S | 7.6440 | 7.6546 | 7.6546 |
| 25% C + 75% adapted S | 7.6623 | 7.6623 | 7.6623 |
| 100% H | 8.9954 | 9.7796 | 9.8791 |
| 100% C | 8.4827 | 9.2332 | 9.1097 |

The teammate's allocation devotes more soldiers to castle 2 and fewer to castles 4 and 5. In our H model, compared with the original candidate, that improves its expected castle-2 score by 0.7355 points but reduces its expected castle-5 score by 1.4544 points. The extra chance of winning castle 2 does not compensate for the loss at castle 5. This explanation is conditional on our modeled opponents, not a universal objection to putting 16 soldiers on castle 2.

## Did the new search find a better strategy?

For the **original eight scenarios**, the original candidate remains optimal under minimax regret. We exhaustively checked all 4,598,126 legal allocations. No different allocation achieves a smaller maximum regret within that original objective, subject to floating-point computation.

However, the team's stated goal includes uncertainty about all H/C/E proportions. We therefore added the pure-H and pure-C endpoints and repeated the complete search. E was already included. This broader objective selects `2 / 2 / 3 / 39 / 54`.

| Largest regret over the specified set | Teammate | Original | New broader candidate |
| --- | ---: | ---: | ---: |
| Original eight populations | 0.6774 | **0.0931** | 0.1502 |
| Every fixed H/C/E mixture | 1.2066 | 0.4224 | **0.3275** |
| Original eight plus pure H and pure C | 1.2066 | 0.4224 | **0.3275** |

The new candidate trades some performance in the concentrated-heavy scenario for better protection when H dominates. It does not beat the original candidate in every scenario. It is better under the broader worst-regret objective.

Why do endpoint checks cover every fixed H/C/E proportion? Suppose no alternative allocation beats ours by more than 0.3275 points against each of H, C, and E. Against a mixture, its advantage is a weighted average of its advantages against those components, so it cannot exceed 0.3275. The same reasoning applies to mixtures of the ten declared population distributions. This is a consequence of additive expected scores, not an assumption that the three types occur equally often.

For the new candidate, regret is 0.322875 against H, 0.327500 against C, and approximately zero against E. Thus the worst regret across all their fixed proportions is 0.327500 points.

This does not cover arbitrary adaptive behavior. If we change the H/C background and let S re-optimize, we obtain a new distribution that may lie outside the tested family. We have retained the three existing adapted populations; we have not solved S for every new background mixture.

**For the stated goal of robustness to uncertain fixed H/C/E proportions, our current choice is `2 / 2 / 3 / 39 / 54`.** If we instead commit to the original eight-scenario objective, `1 / 2 / 2 / 40 / 55` remains the correct choice. Neither result establishes which population best describes the actual tournament.

## How the supplied research affected this update

We used the references to check our methods and the interpretation of opponent models. We did not import allocation vectors or use historical participant percentages to calibrate H and C.

Arad and Rubinstein's human experiments support investigating round-number preferences and small overbids. Their game used 120 soldiers, six equal-value battlefields, and different tie scoring. It therefore supports behavioral mechanisms, not our tournament's type percentages. Our H/C generators remain explicit assumptions. [Original study](https://www.tau.ac.il/~aradayal/blotto.pdf)

The supplied algorithm papers support exact best-response dynamic programming and compact equilibrium computation. Our implementation already handles half-point ties and checks equilibrium against a full-space best response. We kept it. One useful clarification: Vu and coauthors' paper permits half-tie scoring, although its public R example awards ties to one player. Copying that example unchanged would be inappropriate. [DP paper](https://ijcai.org/proceedings/2018/72), [public scoring example](https://raw.githubusercontent.com/dongquan11/Approx_discrete_Blotto/master/CSF.R), [compact LP paper](https://arxiv.org/html/1612.04029v2)

FiveThirtyEight's historical data involve ten castles and a tournament objective based on matchups won. We did not rescale those allocations into five-castle opponents. They may help a later, separate analysis of behavioral features. [Official data description](https://raw.githubusercontent.com/fivethirtyeight/data/master/riddler-castles/README.md)

The numerical change in this update comes from broadening the robustness objective and exhaustively optimizing it, not from claiming new knowledge of actual entrants. Future model validation should vary the H/C generation rules and test mixed H/C backgrounds with S adapting, ideally informed by independent submissions collected under our exact rules.

## Reproducing the comparison

From the project directory, run:

```bash
/opt/anaconda3/envs/baruch/bin/python run_experiments.py
/opt/anaconda3/envs/baruch/bin/python -m unittest discover -s tests -v
```

The runner now records both searches and the teammate comparison. Full numerical details are in [comparison.json](../results/comparison.json); the bilingual experiment output is [summary.md](../results/summary.md). The code's English-then-Chinese explanation is [run_experiments.md](../run_experiments.md). This team note is a written snapshot of the default run; changing the model parameters does not automatically rewrite it.
