# run_experiments.py

## English

**Goal.** Reproduce the Game 1 analysis from one command and save the inputs, assumptions, numerical certificates, and comparisons. Run from this directory:

```bash
/opt/anaconda3/envs/baruch/bin/python run_experiments.py
/opt/anaconda3/envs/baruch/bin/python -m unittest discover -s tests -v
```

On another machine, use Python 3.10 or newer with `requirements.txt` installed, replacing the interpreter path with `python`. The local verified environment is Python 3.12, NumPy 2.5.3, SciPy 1.18.1, Matplotlib 3.11.1. All simulations occur before submission. The program does not submit an application or play changing allocations on the tournament website.

The runner calls small modules in this order:

1. Solve the two exact random baselines. Follow pure responses from four starting vectors and save every transition until a cycle is found.
2. Compute a mixed equilibrium by double oracle and a 10,000-update fictitious-play approximation. Save the complete legal support vectors, their weights, and full-space error histories.
3. Generate 4,000 heuristic and 4,000 concentrated synthetic opponents. Create five fixed scenarios by combining those populations with the equilibrium distribution. Then solve three endogenous scenarios in which the smart subgroup responds to a fixed background **and to itself**. A controlled comparison holds that background and its share fixed, comparing smart players frozen at the original-game equilibrium with jointly adapted smart players.
4. Use DP to find each scenario's exact best response. Enumerate every legal allocation to minimize the maximum regret across the eight scenarios. Repeat with pure H and pure C added, covering arbitrary fixed H/C/E proportions. Compare both optimal vectors with the teammate's `(2,16,1,37,44)`, older candidates, proportional/equal allocations, and the rounded equilibrium mean. `comparison.json` saves the three main candidates' scores and regrets under both objectives. The expanded search keeps the three solved adapted populations but does not recompute S for every new background mixture.
5. Sweep the equilibrium population share from 0 to 1 in steps of 0.05, with three different compositions of the remainder. Finally, evaluate the chosen robust vector against five freshly generated balanced populations. The vector stays fixed during this check. This checks sampling stability within the model, not predictive accuracy for real students.

The fixed scenario weights below follow `(heuristic, concentrated, equilibrium)` order:

| Name | Weights or construction |
| --- | --- |
| `heuristic_heavy` | `(0.50, 0.25, 0.25)` |
| `balanced` | `(0.25, 0.25, 0.50)` |
| `concentrated_heavy` | `(0.10, 0.70, 0.20)` |
| `equilibrium_heavy` | `(0.05, 0.15, 0.80)` |
| `equilibrium` | `(0, 0, 1)` |
| `endogenous_10H` | 10% heuristic, 90% jointly adapted smart play |
| `endogenous_25H` | 25% heuristic, 75% jointly adapted smart play |
| `endogenous_25C` | 25% concentrated, 75% jointly adapted smart play |

These proportions are experiment settings. The “balanced” name does not assert that this is the actual applicant population. The older write-up used an adaptive population that was not fully specified; our equilibrium component is explicitly defined and therefore not a reproduction of its numerical table.

Outputs go to `results/` by default. `summary.md` is the bilingual human-readable report; `summary.json` contains all comparisons, cycle paths, and seed checks. `scenario_marginals.json` saves the exact probability tables used. `equilibrium.json`, `fictitious_play.json`, and three `endogenous_*.json` files save distributions and error histories. `sensitivity.json` stores 63 population settings. `diagnostics.png` shows exploitability against update count on the left and optimal score against assumed equilibrium share on the right. The algorithms have different per-update costs, so the first plot is not a runtime benchmark. Scores are in castle points, out of 15.

The logarithmic error plot displays values below `1e-12` at `1e-12`; JSON preserves the actual residuals. Useful options are `--seed`, `--samples`, `--tolerance`, `--max-iterations`, `--fp-iterations`, and `--output`. For example, `--output results_seed2 --seed 20261203` runs a separate population sample. A solver hitting its iteration limit still saves its residual and `converged=false`; always inspect that field. The default tolerance is `1e-8` points, not an exact-arithmetic proof. Rerunning into the same output directory replaces generated results. The total cost is driven by restricted LP solves and exhaustive regret enumeration; it does not construct a full 4.6-million-square payoff matrix.

## 中文

**目标。** 用一条命令重做第一局分析，保存模型假设、数值证书和候选方案比较。在当前目录运行上面的两条命令，分别完成实验和测试。本机已验证 Python 3.12、NumPy 2.5.3、SciPy 1.18.1、Matplotlib 3.11.1。其他机器可使用 Python 3.10 以上环境，安装 `requirements.txt` 后将解释器路径替换为 `python`。所有反制发生在提交前的离线计算中。

主程序依次调用各模块：

1. 计算两种精确随机基准。从四个起点做纯策略反制，保存直到出现循环为止的全部状态。
2. 用 double oracle 求混合均衡，并计算10,000轮 fictitious play。保存完整合法配兵、混合概率和全空间误差轨迹。
3. 分别生成4,000个直觉型、4,000个集中型对手，与均衡分布组合成五种固定情景。再求三种内生情景，让聪明子群体同时针对背景人群和彼此调整。另外保持背景人群及其比例不变，对照“聪明人固定使用原博弈均衡”与“聪明人共同适应”，单独测量共同适应的影响。
4. 用 DP 求每种情景的精确最佳回应，再枚举所有合法配兵，最小化八种情景中的最大 regret。然后加入纯H和纯C重新全枚举，覆盖H/C/E分布固定时的任意比例。比较两个目标下的最优向量、队友的 `(2,16,1,37,44)`、旧方案、等分、按比例分配和均衡均值取整。`comparison.json` 保存三个主要候选在两个目标下的得分与regret。扩展搜索保留三个已有适应人群，没有为每个新背景混合重新计算S。
5. 将均衡人群比例从0扫到1，步长0.05，分别考虑剩余人群全为集中型、两类各半、全为直觉型。最后换五组种子，重新生成人群，评价已经选定的固定配兵。这里检查的是模型内部的抽样稳定性，并非对真实大学生的预测能力。

五种固定情景的比例依次为 `(直觉型,集中型,均衡型)`：`heuristic_heavy=(0.50,0.25,0.25)`，`balanced=(0.25,0.25,0.50)`，`concentrated_heavy=(0.10,0.70,0.20)`，`equilibrium_heavy=(0.05,0.15,0.80)`，`equilibrium=(0,0,1)`。另外三种情景为10%直觉型加90%相互适应者、25%直觉型加75%相互适应者、25%集中型加75%相互适应者。

这些比例都是实验设置，`balanced` 这个名字不代表它就是实际人群。旧分析中的“自适应型”没有完整定义；这里的均衡分布定义明确，因此不能把本次表格说成对旧数值的复现。

默认输出到 `results/`：`summary.md` 是双语实验报告，`summary.json` 包含全部得分、循环路径与换种子结果；`scenario_marginals.json` 保存实际使用的概率表；`equilibrium.json`、`fictitious_play.json` 和三个 `endogenous_*.json` 保存分布及误差；`sensitivity.json` 保存63组人群设置。`diagnostics.png` 左图横轴为更新次数，纵轴为全空间 exploitability；右图横轴为假定的均衡型比例，纵轴为最佳回应分数。两种算法每轮成本不同，左图不是运行速度比较。得分单位都是城堡分，满分15。

对数误差图将低于 `1e-12` 的数值显示为 `1e-12`；JSON 保留原始残差。可修改的参数包括 `--seed`、`--samples`、`--tolerance`、`--max-iterations`、`--fp-iterations` 和 `--output`。例如添加 `--output results_seed2 --seed 20261203`，会在独立目录保存另一组人群实验。达到迭代上限时仍保存结果，但会标记 `converged=false`，必须结合残差阅读。默认误差容限为 `1e-8` 分，不是精确算术证明。使用相同输出目录重跑会覆盖生成结果。主要成本来自受限 LP 和 regret 全枚举，不会构造4,598,126维的完整计分方阵。
